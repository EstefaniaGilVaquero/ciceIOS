//
//  APIConstantes.swift
//  App_RetoMVCWS
//
//  Created by User on 27/7/16.
//  Copyright © 2016 icologic. All rights reserved.
//

import Foundation

struct APIConstantes {
    
    let BASE_URL = "http://jsonplaceholder.typicode.com/users"
}
